import img from '../assets/logo.png';
import {mapGetters} from 'vuex';
export default {
  name: 'header',
  data() {
    return {
      banner: 'NoManReady',
      color:'green'
    };
  },
  computed:{
    ...mapGetters(['title']),
  },
  methods:{
    changeColor(){
      this.color='red';
    }
  },
  mounted(){
    this.img=img;
  }
};
