<template>
    <div class="chart" v-echarts="line"></div>
</template>

<script>
    import Personal from './js/Statis';
    export default Personal;
</script>

<style lang="scss" scoped>
    @import './scss/statis';
</style>
