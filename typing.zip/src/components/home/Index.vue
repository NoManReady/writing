<template>
  <div class="typing-home">
    <div class="home-header">
        <img class="logo" src="../../assets/logo.png" alt="logo">
        <p class="title">欢迎使用ND打字测试软件</p>
    </div>
    <div class="mode-block">
        <div v-for="(mode,index) in modeHash" class="mode-item" :style="{backgroundImage:`url(${mode.img})`}" :key="index">
            <a @click="modeClick(mode.mode)">{{mode.name}}</a>
        </div>
    </div>
  </div>
</template>
<script>
import {
    mapGetters,
    mapActions
} from 'vuex';
export default {
    name: 'typingMode',
    data() {
        return {}
    },
    computed: {
        ...mapGetters(['modeHash'])
    },
    methods: {
        ...mapActions(['set_mode']),
        modeClick(mode) {
            this.set_mode(mode);
            this.$nextTick(() => {
                this.$router.replace('/articles');
            });
        }
    }
}
</script>
<style lang="scss" scoped>
@import "../../scss/mixins";
.typing-home {
    text-align: center;

    color: #fff;
    background: url(../../assets/1920.jpg) center center no-repeat;
    background-size: cover;

    @extend %position-absolute;
    .home-header {
        margin-top: 130px;
        .logo {
            width: 47px;
            height: 54px;
        }
        .title {
            font-size: 24px;
        }
    }
    $blockSize: 238px;
    .mode-block {
        margin-top: 100px;
        .mode-item {
            display: inline-block;

            width: $blockSize;
            height: $blockSize;

            font-size: 32px;
            line-height: 136px;
            text-align: center;
            a {
                display: block;

                margin-left: 57px;
                width: 141px;
                height: 141px;

                cursor: pointer;
                &:hover {
                    color: darken(#fff,10%);
                }
            }
        }
    }
}

</style>
