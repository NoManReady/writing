<script
    src="../../../../../boss/elearn_base_s1_e_101_com/auxo/component/js-enroll-status/v1.0.0/enrollstatus.js"></script>
<link rel="stylesheet"
      href="../../../../../boss/elear_base_pre_r_s1_e_99_com/auxo/front/mystudy/scss/shared/_iconfont.scss">
<template>
    <div class="myrank-conent">
        <div class="myrank-c-t"
             v-if="rankList.print_type_rank.length || rankList.article_type_rank.length || rankList.article_rank.length">
            <div class="myrank-list fl">
                <span class="bg">我</span>
                <label>我的输入法</label>
                <p>{{allStatisticData.name | filter2}}</p>
                <ul v-if="allStatisticData.name!='--'">
                    <li v-for="(item,index) in rankList.print_type_rank">
                        <span class="td1"
                              :class="{top1:item.rank==1,top2:item.rank==2,top3:item.rank==3}">{{item.rank | filter1}}</span>
                        <span class="td2" :class="{blue:item.user_id==loginUser.user_id}">
                            <img :src="item.icon">&nbsp;{{item.display_name}}
                        </span>
                        <span class="td3" :class="{blue:item.user_id==loginUser.user_id}">{{item.score}}字/分</span>
                    </li>
                </ul>
                <div class="notyperank" v-else>
                    <img src="../../assets/sametype.jpg">
                    <p>要用同种输入法测试才有排行哦！</p>
                </div>
            </div>
            <div class="myrank-list fl">
                <span class="bg">同</span>
                <label>同文本排名</label>
                <p class="overflow vm w90" :title="typingName">{{typingName}}</p>
                <ul>
                    <li v-for="(item,index) in rankList.article_type_rank">
                        <span class="td1"
                              :class="{top1:item.rank==1,top2:item.rank==2,top3:item.rank==3}">{{item.rank | filter1}}</span>
                        <span class="td2" :class="{blue:item.user_id==loginUser.user_id}">
                            <img :src="item.icon">&nbsp;{{item.display_name}}
                        </span>
                        <span class="td3" :class="{blue:item.user_id==loginUser.user_id}">{{item.score}}字/分</span>
                    </li>
                </ul>
            </div>
            <div class="myrank-list fr">
                <span class="bg">混</span>
                <label>中英混合排名</label>
                <p>&nbsp;</p>
                <ul>
                    <li v-for="(item,index) in rankList.article_rank">
                        <span class="td1"
                              :class="{top1:item.rank==1,top2:item.rank==2,top3:item.rank==3}">{{item.rank | filter1}}</span>
                        <span class="td2" :class="{blue:item.user_id==loginUser.user_id}">
                            <img :src="item.icon">&nbsp;{{item.display_name}}
                        </span>
                        <span class="td3" :class="{blue:item.user_id==loginUser.user_id}">{{item.score}}字/分</span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="myrank-c-f" v-else>
            <div v-if="typingArticle.is_default==1">
                <img src="../../assets/norank.jpg">
                <p>自定义文本不计入排名哦！</p>
            </div>
            <div v-else>
                <img src="../../assets/404.jpg">
                <p>网络走神了，请检查网络！</p>
            </div>
        </div>
    </div>
</template>
<script>
    import {mapGetters, mapActions} from 'vuex';
    export default{
        name: 'rank',
        data(){
            return {};
        },
        methods: {
            ...mapActions(['rank_list'])
        },
        computed: {
            ...mapGetters(['rankList', 'currentTestdata', 'typingName', 'allStatisticData', 'typingArticle', 'loginUser']),
        },
        filters: {
            filter1(index){
                return index > 3 ? index : '';
            },
            filter2(v){
                return v == '--' ? '' : v;
            }
        },
        created(){
            this.rank_list(this.currentTestdata.id);
        }
    }
</script>
<style lang="scss" scoped>
    @import "./scss/rank";
</style>
