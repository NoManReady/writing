// 文章列表
export const GET_ARTICLES='GET_ARTICLES';
// 文章类别
export const GET_CATALOGS='GET_CATALOGS';
// 编码类型
export const SET_CODE='SET_CODE';
// 时限
export const SET_LIMIT='SET_LIMIT';
// 编辑文章id
export const SET_ARTICLEID='SET_ARTICLEID';
// 编辑文章分类id
export const SET_CATALOGID='SET_CATALOGID';
// 删除文章
export const DEL_ARTICLE='DEL_ARTICLE';
// 创建文章
export const CREATE_ARTICLE='CREATE_ARTICLE';
// 重置状态
export const RESET_SETTING='RESET_SETTING';
// 设置用户编码
export const SET_USERCONFIGURE='SET_USERCONFIGURE';
// 获取用户编码
export const GET_USERCONFIGURE='GET_USERCONFIGURE';
