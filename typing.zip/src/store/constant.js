export const APP_TITLE='APP_TITLE';
export const APP_LOADING='APP_LOADING';
export const LOGIN_USER='LOGIN_USER';
export const SET_CRUMB='SET_CRUMB';
