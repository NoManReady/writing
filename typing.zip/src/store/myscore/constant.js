export const MY_MEDAL='MY_MEDAL';
export const RANK_LIST='RANK_LIST';
export const SEARCH='SEARCH';