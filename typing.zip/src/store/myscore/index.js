import Vue from 'vue';
import * as CONST from './constant';
export default {
    state: {
        medalList: Object.freeze({
            reward_medal_info_list: [],
            un_reward_medal_info_list: []
        }),
        rankList: Object.freeze({
            print_type_rank:[],
            article_type_rank:[],
            article_rank:[]
        }),
        progressList: Object.freeze([])
    },
    actions: {
        my_medal({
            commit
        }){
            return Vue.http.get('/' + window.project_code + `/v1/my_medal`).then(response=> {
                commit(CONST.MY_MEDAL, response.body);
            });
        },
        rank_list({
            commit
        }, typewriting_id){
            return Vue.http.get('/' + window.project_code + '/v1/rank/' + typewriting_id).then(response=> {
                commit(CONST.RANK_LIST, response.body);
            });
        },
        search({
            commit
        }){
            return Vue.http.get('/' + window.project_code + '/v1/typewritings/search', {
                params: {
                    user_id: window.user.user_id,
                    page: 0,
                    size: 20
                }
            }).then(response=> {
                commit(CONST.SEARCH, response.body);
            });
        }
    },
    mutations: {
        [CONST.MY_MEDAL](state, medalList){
            state.medalList = Object.freeze(medalList);
        },
        [CONST.RANK_LIST](state, rankList){
            state.rankList = Object.freeze(rankList);
        },
        [CONST.SEARCH](state, data){
            state.progressList = Object.freeze(data);
        }
    },
    getters: {
        medalList(state){
            return state.medalList;
        },
        rankList(state){
            return state.rankList;
        },
        progressList(state){
            return state.progressList;
        }
    }
}
