// content
export const INIT_CONTENT='INIT_CONTENT';
export const INIT_CODELIST='INIT_CODELIST';
export const SET_CURRENTWORD_POSITION='SET_CURRENTWORD_POSITION';
// timer
export const BEGIN_TIMER='BEGIN_TIMER';
export const PAUSE_TIMER='PAUSE_TIMER';
export const RESUME_TIMER='RESUME_TIMER';
// line
export const SET_LINE='SET_LINE';
export const SET_TIME='SET_TIME';
// remain
export const SET_REMAIN_CONTENT='SET_REMAIN_CONTENT';
export const SET_REMAIN_PREV='SET_REMAIN_PREV';
export const SET_CURSOR_POSITION='SET_CURSOR_POSITION';


export const SET_POSITION_PUSH='SET_POSITION_PUSH';
export const SET_CHARSTIME_PUSH='SET_CHARSTIME_PUSH';
// 设置全部统计数据
export const SET_ALLDATA='SET_ALLDATA';
export const RESET_TIMELINE='RESET_TIMELINE';

//提交本次打字测试数据
export const POST_DATA='POST_DATA';
