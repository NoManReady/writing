// 打字模式
export const SET_MODE = 'SET_MODE';
