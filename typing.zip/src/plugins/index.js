import lifecircle from './lifecircle';
export default {
  install(vue,options){
    lifecircle(vue,options);
  }
}
